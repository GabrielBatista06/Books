import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CandidatoService } from './services/libro.service';
import { HttpClientModule } from '@angular/common/http';
import { CrearCandidatoComponent } from './modals/crear-candidato/crear-candidato.component';
import { ReactiveFormsModule } from '@angular/forms';
import { NgxLoadingModule } from 'ngx-loading';
import {MatSnackBarModule} from '@angular/material/snack-bar'
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { DetailsComponent } from './app/details/details.component';


@NgModule({
  declarations: [
    AppComponent,
    CrearCandidatoComponent,
    DetailsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    ReactiveFormsModule,
    NgbModule,
    MatSnackBarModule,
    BrowserAnimationsModule,
    NgxLoadingModule.forRoot({})

  ],
  providers: [
    CandidatoService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
