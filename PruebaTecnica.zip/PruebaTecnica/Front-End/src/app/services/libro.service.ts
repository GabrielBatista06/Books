import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ILibro, ILibroGet } from '../modelos/interfaces/ILibro';


@Injectable({
  providedIn: 'root'
})
export class CandidatoService  {

  private myAppUrl='https://localhost:44329/';
  private myApiUrl='api/Books/'
  constructor(public http: HttpClient) {


   }


  crearLibro(libro: ILibro){
    return this.http.post(this.myAppUrl +this.myApiUrl, libro );
  }

  editarLibro(libroUpdate: ILibroGet){
    console.log(libroUpdate);
    return this.http.put( this.myAppUrl +this.myApiUrl, libroUpdate );
  }

  obtenerLibros(){
    return this.http.get( this.myAppUrl + this.myApiUrl);
  }

  getByIdLibro(id:number){
    return this.http.delete(this.myAppUrl + this.myApiUrl+id)
  }

  eliminarLibro(id: number){
    return this.http.delete( this.myAppUrl + this.myApiUrl+id );
  }

}
