import { Component } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import Swal from 'sweetalert2';
import { DetailsComponent } from './app/details/details.component';
import { CrearCandidatoComponent } from './modals/crear-candidato/crear-candidato.component';
import {  ILibroGet } from './modelos/interfaces/ILibro';
import { CandidatoService } from './services/libro.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'candidatosApp';

  loading: boolean =false;
  libroList: ILibroGet[] = [];

  constructor(private libroServices: CandidatoService,
              private modalService: NgbModal,
              private snackbar: MatSnackBar
             ){

  }
  ngOnInit(): void {
    this.obtenerlibro();
  }

  //Funcion que llama el servicio que elimina un libro
  remover(libro: any){
    Swal.fire({
      title: '¿Seguro que de sea eleminar el libro?',
      text: "No podra revertir esto!",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Si, eliminalo!'
           }).then((result) => {
      if (result.isConfirmed) {
    this.loading=true;
    this.libroServices.eliminarLibro(libro.id)
          .subscribe(res=>{
            Swal.fire(
              'Eliminado!',
              'El libro fue eliminado!',
              'success'
            )
            this.obtenerlibro();
            this.loading=false;
    }, error=>{
      this.loading=false;
      this.snackbar.open("Error conectando con el servidor", "Aceptar");
        });
      }
    })


  }

  //funcion que abre el modal para editar
  editar(libro: any){

    const modalRef = this.modalService.open(CrearCandidatoComponent, { centered: true, size:"lg"} );
    modalRef.componentInstance.libroUpdate = libro;
    modalRef.componentInstance.editar = true;
    modalRef.result.then(res =>{
      if(res){
       this.obtenerlibro();
      }
    }).catch(_=>{

    });


  }
  details(libro: any){

    const modalRef = this.modalService.open(DetailsComponent, { centered: true, size:"xl"} );
    modalRef.componentInstance.libro = libro;
    modalRef.result.then(res =>{
      if(res){
      }
    }).catch(_=>{

    });


  }

  //funcion que abre el modal para crear
  crearlibro(){
    const modalRef = this.modalService.open(CrearCandidatoComponent, { centered: true, size:"lg"} );
    modalRef.result.then(res =>{
      if(res){
        this.obtenerlibro();
      }
    }).catch(_=>{
    });
  }


  obtenerlibro(){
       this.loading= true;
       this.libroServices.obtenerLibros().subscribe((res: any)=>{
       this.loading= false;
        this.libroList= res;
    }, error=>{
      this.loading= false;
      this.snackbar.open("Error conectando con el servidor", "Aceptar");
    })
  }

  getByIdLibro(libro:any){
    this.loading=true;
    this.libroServices.getByIdLibro(libro).subscribe((res:any)=>{
      console.log(res);
      this.loading=false;
      this.libroList=res;
    },error=>{
      this.loading=false;
      this.snackbar.open("Error conectando con el servidor", "Aceptar");
    })
  }
}
