export interface ILibro {


  titulo:string;
  autor:string;
  genero:string;
  fechaPublicacion:Date;
  editorial:string;
  precio:number;
  descripcion:string

}


export interface ILibroGet {

  id: number;
  titulo:string;
  autor:string;
  genero:string;
  fechaPublicacion:Date;
  editorial:string;
  precio:number;
  descripcion:string

}
