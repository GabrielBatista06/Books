import { ILibro } from "../interfaces/ILibro";
export class Libro implements ILibro {


  titulo: string='';
  autor: string='';
  genero: string='';
  fechaPublicacion: Date=new Date();
  editorial: string='';
  precio: number=0;
  descripcion: string='';

}
