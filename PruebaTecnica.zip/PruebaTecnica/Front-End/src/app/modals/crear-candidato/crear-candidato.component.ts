import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { Libro } from 'src/app/modelos/clases/Libro';
import { ILibro} from 'src/app/modelos/interfaces/ILibro';
import { CandidatoService } from 'src/app/services/libro.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-crear-candidato',
  templateUrl: './crear-candidato.component.html',
  styleUrls: ['./crear-candidato.component.css']
})
export class CrearCandidatoComponent implements OnInit {

  libroForm: FormGroup;
  libro: ILibro = new Libro();
  libroUpdate: any;
  loading: boolean;
  editar: boolean
  tituloFormulario: string ;
  date: Date = new Date();

  constructor(private fb: FormBuilder,
              private librotoServices: CandidatoService,
              public activeModal: NgbActiveModal,
              private snackbar: MatSnackBar) { }

  ngOnInit(): void {
    if(this.editar){
      this.tituloFormulario ="Actualizar libro";
      this.updateFormulario();

    }else{
      this.tituloFormulario ="Crear libro";
      this.crearFormulario();
    }
  }


    //Crea el formulario para crear
  crearFormulario(){
    this.libroForm = this.fb.group({
      titulo: ['', Validators.required],
      autor: ['', Validators.required] ,
      genero: ['', Validators.required],
      fechaPublicacion: ['', Validators.required],
      editorial: ['', Validators.required],
      descripcion: [''],
      precio: ['', Validators.required],
    })
  }

  //Crea el formulario para actualizar
  updateFormulario(){
    this.libroForm = this.fb.group({
      titulo: [this.libroUpdate.titulo, Validators.required],
      autor: [this.libroUpdate.autor, Validators.required] ,
      genero: [this.libroUpdate.genero, Validators.required],
      fechaPublicacion: [this.libroUpdate.fechaPublicacion, Validators.required],
      editorial: [this.libroUpdate.editorial, Validators.required],
      descripcion: [this.libroUpdate.descripcion],
      precio: [this.libroUpdate.precio, Validators.required],
    })
  }

  //funcion que llama el servicio que crea
  crearlibro(){

    if(this.libroForm.invalid){
      this.libroForm.markAllAsTouched();
      return
    }
    this.loading =true;
    this.maplibro();
    this.librotoServices.crearLibro(this.libro).subscribe((res: any)=>{
      this.loading=false;
     this.activeModal.close(res);
     Swal.fire(
      'Creado!',
      'El libro fue creado correctamente!',
      'success'
    )

    }, error=>{
      this.loading = false;

      if(error.status==400){
        this.snackbar.open("Error conectando con el servidor", "Aceptar");
      }
      this.snackbar.open("Error conectando con el servidor", "Aceptar");
      this.activeModal.close();
    });
  }

    //Funcóon que llama el servicio que actualiza
  updatelibro(){
    if(this.libroForm.invalid){
      return
    }
    this.loading =true;
    let libroActualizado= this.mapUpdatelibro();
    this.librotoServices.editarLibro(libroActualizado).subscribe(res=>{
      this.activeModal.close(res);
      Swal.fire(
        'Actualizado!',
        'El libro fue actualizado correctamente!',
        'success'
      )

      this.loading=false;

    }, error=>{
      this.loading = false;
      this.snackbar.open("Error conectando con el servidor", "Aceptar");
      this.activeModal.close();
    });
  }

  //Mapeo del libro para crearlo
  maplibro(){
    this.libro.titulo = this.libroForm.value.titulo;
    this.libro.autor = this.libroForm.value.autor;
    this.libro.fechaPublicacion = this.libroForm.value.fechaPublicacion;
    this.libro.editorial = this.libroForm.value.editorial;
    this.libro.precio = this.libroForm.value.precio;
    this.libro.genero = this.libroForm.value.genero;
    this.libro.descripcion = this.libroForm.value.descripcion;

  }

    //Mapeo del libro para actualizar
  mapUpdatelibro(){
    const libroUp = {
        id: this.libroUpdate.id,
        titulo: this.libroForm.value.titulo,
        autor: this.libroForm.value.autor,
        fechaPublicacion: this.libroForm.value.fechaPublicacion,
        editorial: this.libroForm.value.editorial,
        precio:  this.libroForm.value.precio,
        genero: this.libroForm.value.genero,
        descripcion: String(this.libroForm.value.descripcion)
    }

    return libroUp
  }

  //Función que llama el metodo crear o actualizar segun se necesite
  guardar(){
    if(this.editar){
      console.log("Editar");
      this.updatelibro();
    }else{
      this.crearlibro();
    }
  }



}
