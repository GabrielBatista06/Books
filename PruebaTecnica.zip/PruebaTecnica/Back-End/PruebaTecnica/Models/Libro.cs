﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace PruebaTecnica.Models
{
    public class Libro
    {
        [Key]
        public int Id { get; set; }
        [Required]
        public string Titulo { get; set; }
        [Required]
        public string Autor { get; set; }
        [Required]
        public string Genero { get; set; }
        public DateTime FechaPublicacion { get; set; }
        public string Editorial { get; set; }
        [Required]
        public double Precio { get; set; }
        public string Descripcion { get; set; }

    }
}
