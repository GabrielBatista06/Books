﻿using AutoMapper;
using PruebaTecnica.DTOs;
using PruebaTecnica.Models;

namespace PruebaTecnica.ProfileAutoMapper
{
    public class AutoMapperProfiles: Profile
    {
        public AutoMapperProfiles()
        {
            CreateMap<Libro, LibroDTO>().ReverseMap();

            CreateMap<LibroCreateDTO, Libro>();

            CreateMap<LibroUpdateDTO, Libro>().ReverseMap();
        }
    }
}
