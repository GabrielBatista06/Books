﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PruebaTecnica.DTOs
{
    public class LibroCreateDTO
    {
        public string Titulo { get; set; }
        public string Autor { get; set; }
        public string Genero { get; set; }
        public DateTime FechaPublicacion { get; set; }
        public string Editorial { get; set; }
        public double Precio { get; set; }
        public string Descripcion { get; set; }
    }
}
