﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PruebaTecnica.AplicatioDbContext;
using PruebaTecnica.DTOs;
using PruebaTecnica.Models;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace PruebaTecnica.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BooksController : ControllerBase
    {
        private readonly AplicationDbContext _context;
        private readonly IMapper _mapper;

        public BooksController(AplicationDbContext context,
                                             IMapper mapper)
        {
            this._context = context;
            this._mapper = mapper;
        }

        //GET /api/Books
        [HttpGet]
        public async Task<ActionResult<List<LibroDTO>>> Get()
        {
            var books = await _context.Libros.ToListAsync();

            if (books==null)
            {
                return NotFound();
            }

            return _mapper.Map<List<LibroDTO>>(books);

        }

        //GET /api/Books/{id}
        [HttpGet("{id}")]
        public async Task<ActionResult<Libro>>GetById(int id)
        {
            var book = await _context.Libros.FindAsync(id);

            if (book==null)
            {
                return NotFound();
            }

            return Ok(book);
        }

        //POST /api/Books/
        [HttpPost]
        public async Task<ActionResult> Post([FromBody] LibroCreateDTO libroCreateDTO)
        {

            try
            {
                var result = _mapper.Map<Libro>(libroCreateDTO);

                _context.Add(result);

                await _context.SaveChangesAsync();

                return Ok(new { message = "Libro registrado con éxito" });
            }
            catch (Exception ex)
            {

                return Ok(ex.Message);
            }


        }

        //PUT /api/Books/{id}
        [HttpPut("{id}")]
        public async Task<ActionResult> Put(int id, LibroUpdateDTO libroUpdateDTO)
        {
            var result = await _context.Libros.FirstOrDefaultAsync(c => c.Id == id);
            if (result == null)
            {
                return NotFound();
            }
            _mapper.Map(libroUpdateDTO, result);
            _context.Entry(result).State = EntityState.Modified;
            await _context.SaveChangesAsync();

            return Ok(new { message = "Libro actualizado con éxito" });
        }

        //Delete /api/Books/{id}
        [HttpDelete("{id}")]
        public async Task<ActionResult> Delete(int id)
        {
            var result = await _context.Libros.FindAsync(id);

            if (result == null)
            {
                return NotFound();
            }

            _context.Libros.Remove(result);
            await _context.SaveChangesAsync();

            return Ok(new { message = "Libro eliminado con éxito" });
        }


    }
}
